import hashlib
import tkinter as tk  # 使用Tkinter前需要先导入

from tkinter import Tk  # Python 3




def compute_sha256(input):
    h = hashlib.new('sha256',b"swufe")
    return h.hexdigest()

h = hashlib.new('sha256',b"swufe")
print(h.hexdigest())

#clip = Tk().clipboard_get()

try:
    clip=Tk().clipboard_get()
except BaseException:
    clip=''
